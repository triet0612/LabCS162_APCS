#include <iostream>
#include <vector>
using namespace std;

void permutation(vector<int> &num, int x, int &len, vector<vector<int>> &ans);

vector<vector<int>> permute(int n);