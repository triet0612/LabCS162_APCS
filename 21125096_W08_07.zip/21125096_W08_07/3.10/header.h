#include <iostream>
#include <vector>
using namespace std;

void permutation(string &str, int x, int &len, vector<string> &ans);

vector<string> permute(string &str);